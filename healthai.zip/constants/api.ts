export const BASE_URL = "https://healthai.smartncode.com";

// ─── URL-PREFIX NOTE ──────────────────────────────────────────────────────────
// Auth endpoints:    BASE_URL + /api/auth/...       (single /api)
// Reports endpoints: BASE_URL + /api/...            (single /api)
// AI endpoints:      BASE_URL + /ai/...             (no /api prefix)
//
// Medicine + Profile endpoints: BASE_URL + /api/api/...  (double /api)
//   Confirmed from backend: /api/api/medicines/search works.
//   All medicines/* and user/* routes follow the same double-prefix pattern.
// ─────────────────────────────────────────────────────────────────────────────

export const ENDPOINTS = {
  // ── Auth ──────────────────────────────────────────────────────────────────
  login:                   `${BASE_URL}/api/auth/login`,
  signup:                  `${BASE_URL}/api/auth/signup`,
  googleLogin:             `${BASE_URL}/api/auth/google-login`,
  sendOtp:                 `${BASE_URL}/api/auth/send-otp`,
  verifyOtp:               `${BASE_URL}/api/auth/verify-otp`,

  // Auth — Forgot Password
  forgotPasswordSendOtp:   `${BASE_URL}/api/auth/forgot-password/send-otp`,
  forgotPasswordVerifyOtp: `${BASE_URL}/api/auth/forgot-password/verify-otp`,
  forgotPasswordReset:     `${BASE_URL}/api/auth/forgot-password/reset`,

  // Auth — Session
  refreshToken:            `${BASE_URL}/api/auth/refresh-token`,
  logout:                  `${BASE_URL}/api/auth/logout`,

  // Auth — Onboarding
  saveOnboarding:          `${BASE_URL}/api/auth/onboarding`,

  // ── Profile (/api/api/user/...) ───────────────────────────────────────────
  profileMe:     `${BASE_URL}/api/api/user/profile`,
  profileMePath: '/api/api/user/profile',           // relative path for api.request()
  profileAvatar: `${BASE_URL}/api/api/user/profile/avatar`,
  deleteAccount: `${BASE_URL}/api/api/user/account`,

  // ── Reports ───────────────────────────────────────────────────────────────
  analyzeReport:   `${BASE_URL}/api/analyze-report`,
  listReports:     `${BASE_URL}/api/reports`,
  scorecardReport: `${BASE_URL}/api/reports/scorecard`,
  reportDetail:    (id: string) => `${BASE_URL}/api/reports/${id}`,
  reportDelete:    (id: string) => `${BASE_URL}/api/reports/${id}`,

  // ── AI Assistant ──────────────────────────────────────────────────────────
  aiChat:     `${BASE_URL}/ai/chat`,
  aiNarrative:`${BASE_URL}/ai/narrative`,
  aiSessions: `${BASE_URL}/ai/sessions`,
  aiSession:  (id: string) => `${BASE_URL}/ai/sessions/${id}`,

  // ── Medicines — Browse (/api/api/medicines/...) ───────────────────────────
  medicineCategories:  `${BASE_URL}/api/api/medicines/categories`,
  medicineSearch:      `${BASE_URL}/api/api/medicines/search`,
  medicinesByCategory: `${BASE_URL}/api/api/medicines`,
  medicineDetails:     (id: string) => `${BASE_URL}/api/api/medicines/${id}`,
  medicineRecent:      `${BASE_URL}/api/api/medicines/recent`,
  medicinePopular:     `${BASE_URL}/api/api/medicines/popular`,

  // ── Medicines — Saved / User Medicines (/api/api/user/...) ───────────────
  userMedicines:      `${BASE_URL}/api/api/user/medicines`,
  userMedicineRemove: (id: string) => `${BASE_URL}/api/api/user/medicines/${id}`,

  // ── Medicines — Reminders (/api/api/reminders/...) ───────────────────────
  reminders:             `${BASE_URL}/api/api/reminders`,
  remindersToday:        `${BASE_URL}/api/api/reminders/today`,
  reminderTaken:         (id: string) => `${BASE_URL}/api/api/reminders/${id}/taken`,
  reminderMissed:        (id: string) => `${BASE_URL}/api/api/reminders/${id}/missed`,
  reminderHistory:       `${BASE_URL}/api/api/reminders/history`,
  reminderUpdate:        (id: string) => `${BASE_URL}/api/api/reminders/${id}`,
  reminderDelete:        (id: string) => `${BASE_URL}/api/api/reminders/${id}`,

  // ── Medicines — Scanner (/api/api/medicine-scanner/...) ──────────────────
  scannerUpload:  `${BASE_URL}/api/api/medicine-scanner/upload`,
  scannerResult:  (scanId: string) => `${BASE_URL}/api/api/medicine-scanner/result/${scanId}`,
  scannerHistory: `${BASE_URL}/api/api/medicine-scanner/history`,

  // ── Medicines — Interaction Checker (/api/api/interactions/...) ──────────
  interactionsCheck:        `${BASE_URL}/api/api/interactions/check`,
  interactionDetails:       (id: string) => `${BASE_URL}/api/api/interactions/${id}`,
  interactionsSave:         `${BASE_URL}/api/api/interactions/save`,
  interactionsHistory:      `${BASE_URL}/api/api/interactions/history`,
  interactionHistoryDelete: (id: string) => `${BASE_URL}/api/api/interactions/history/${id}`,
  interactionsAiSummary:    `${BASE_URL}/api/api/interactions/ai-summary`,
};